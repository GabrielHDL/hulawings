<?php

define('servidor', $servidor);
define('nombre_bd', $basedatos);
define('usuario', $usuario);
define('password', $pass);

?>