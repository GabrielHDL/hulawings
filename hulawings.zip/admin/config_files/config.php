<?php

$site_title = "HULA Wings&reg;";
$drinks_title = "Drinks";
$donde_title = "¿Dónde?";
$bajon_title = "Bajón";
$servidor = "localhost";
$basedatos = "hula_wings";
$usuario = "root";
$pass = "";

?>